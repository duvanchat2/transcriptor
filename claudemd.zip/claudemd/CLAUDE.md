# CLAUDE.md — Reglas del agente de edición de video
# Ubicación: edit/hyperframes/CLAUDE.md
# Leer OBLIGATORIAMENTE al inicio de cada sesión

---

## IDENTIDAD DEL PROYECTO

**Canal:** Duvan — IA aplicada a Marketing y Ecommerce latinoamericano  
**Formato:** Videos verticales 1080×1920px (Instagram Reels, TikTok, YouTube Shorts)  
**Estilo visual de referencia:** Competidor analizado y medido — ver SISTEMA VISUAL abajo  
**Pipeline:** 5 fases en orden estricto. No saltarse ninguna.

---

## SISTEMA VISUAL — EL ESTILO QUE DEBES REPLICAR

Esta es la referencia medida directamente de la imagen del competidor.  
**Estos números son exactos. No estimar. No cambiar sin aprobación de Duvan.**

### Canvas y escala

```
Canvas HyperFrames: 1080×1920px (vertical, IGUAL que el video final)
Video final:        1080×1920px (vertical)
Relación:           1:1 — 1px CSS = 1px en el video final
offset_y:           0 (el canvas CUBRE todo el video)
```

**REGLA ABSOLUTA:** El canvas SIEMPRE es 1080×1920. NUNCA cambiarlo a otro tamaño.
Si cambias el canvas, TODOS los valores de CSS dejan de funcionar.

### Elemento 1 — HOOK BOX (parte superior, fijo todo el video)

```css
.hook-box {
  position: absolute;
  top: 110px;                       /* ~5.7% desde arriba */
  left: 50%;
  transform: translateX(-50%);
  
  background: rgba(255, 255, 255, 0.95);
  color: #111111;
  
  font-family: Inter, system-ui, -apple-system, sans-serif;
  font-size: 32px;                  /* VALIDADO — aprobado por Duvan 2026-05-01 */
  font-weight: 700;
  line-height: 1.3;
  letter-spacing: -0.01em;
  text-align: center;
  
  padding: 12px 18px;               /* MEDIDO */
  border-radius: 12px;              /* MEDIDO */
  max-width: 82%;
  
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.20);
}
```

**Comportamiento:** Aparece en el segundo 0. **Desaparece a los 5s.**
**Entrada:** `gsap.set('#hook', {opacity:0, y:-30})` + `tl.to('#hook', {opacity:1, y:0, duration:0.4, ease:'power3.out'}, 0.1)`
**Salida:** `tl.to('#hook', {opacity:0, duration:0.3, ease:'power2.in'}, 5.0)`
**Texto:** El hook del guión — máximo 3 líneas. Duvan lo provee.

---

### Elemento 2 — SUBTITLE PILL (subtítulos karaoke, parte inferior)

```css
/* Contenedor de subtítulos — posición fija */
.subtitles-container {
  position: absolute;
  bottom: 385px;                    /* MEDIDO — 20% desde abajo */
  left: 0;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 5px;
  flex-wrap: wrap;
  padding: 0 80px;
}

/* Cada palabra */
.word {
  background: rgba(255, 255, 255, 0.92);
  color: #111111;
  
  font-family: Inter, system-ui, -apple-system, sans-serif;
  font-size: 28px;                  /* VALIDADO — aprobado por Duvan 2026-05-01 */
  font-weight: 600;                 /* semibold, NO black */
  line-height: 1.0;
  
  padding: 4px 10px;                /* MEDIDO — compacto */
  border-radius: 5px;               /* MEDIDO */
  
  white-space: nowrap;
}

/* Palabra activa (karaoke highlight) */
.word.active {
  background: #111111;
  color: #ffffff;
}
```

**Comportamiento:** 2 palabras por cue. Palabra activa tiene fondo oscuro.  
**Timing:** Sincronizado con el transcript word-level de AssemblyAI.  
**data-track-index:** Siempre >= 30

---

### Elemento 3 — KEYWORD PILL (palabras clave del video)

```css
.keyword-pill {
  position: absolute;
  top: 42%;                         /* centro-medio de la pantalla */
  left: 50%;
  transform: translateX(-50%);
  
  background: #111111;
  color: #ffffff;
  
  font-family: Inter, system-ui, -apple-system, sans-serif;
  font-size: 38px;                  /* VALIDADO — aprobado por Duvan 2026-05-01 */
  font-weight: 800;
  line-height: 1.2;
  text-align: center;
  
  padding: 10px 20px;
  border-radius: 10px;
  
  white-space: nowrap;
  opacity: 0;                       /* empieza invisible — GSAP lo anima */
}

/* Variante blanca para contraste (cuando el fondo es muy oscuro) */
.keyword-pill.light {
  background: rgba(255, 255, 255, 0.95);
  color: #111111;
}
```

**Comportamiento:** Aparece cuando se menciona una keyword. Dura 2 segundos.  
**Entrada:** `gsap.to()` con opacity:1, y:0, scale:1, duration:0.3, ease:'back.out(1.4)'  
**Salida:** `gsap.to()` con opacity:0, duration:0.2, ease:'power2.in'  
**data-track-index:** Siempre >= 20, < 30

---

### Elemento 4 — STICKER CONTEXTUAL

```css
.sticker {
  position: absolute;
  bottom: 200px;                 /* encima de los subtítulos */
  opacity: 0;                       /* empieza invisible */
  
  filter: drop-shadow(0 4px 12px rgba(0, 0, 0, 0.35));
}

/* Posiciones disponibles */
.sticker.bottom-left   { left: 6%; }
.sticker.bottom-center { left: 50%; transform: translateX(-50%); }
.sticker.bottom-right  { right: 6%; }
```

**Comportamiento:** Aparece cuando se menciona el producto/herramienta. Dura 3 segundos.  
**Tamaño:** width y height definidos en el JSON del sticker (entre 70-100px).  
**Entrada:** `gsap.to()` con opacity:1, scale:1, duration:0.35, ease:'back.out(1.7)'  
**Salida:** `gsap.to()` con opacity:0, scale:0.8, duration:0.2  
**data-track-index:** Siempre >= 40

---

### Keywords que activan pills (nicho de Duvan)

```python
KEYWORD_PILLS = {
    "claude":           "Claude",
    "claude code":      "Claude Code",
    "chatgpt":          "ChatGPT",
    "chat gpt":         "ChatGPT",
    "gpt":              "GPT",
    "meta ads":         "Meta ADs",
    "facebook ads":     "Facebook Ads",
    "fb ads":           "FB Ads",
    "instagram":        "Instagram",
    "tiktok":           "TikTok",
    "agente":           "Agente IA",
    "agente ia":        "Agente IA",
    "automatización":   "Automatización",
    "ugc":              "UGC",
    "freepik":          "Freepik",
    "ecommerce":        "Ecommerce",
    "whatsapp":         "WhatsApp",
    "notion":           "Notion",
    "make":             "Make.com",
    "n8n":              "n8n",
    "openai":           "OpenAI",
    "gemini":           "Gemini",
    "anthropic":        "Anthropic",
}
```

---

## REGLAS DE HYPERFRAMES — NO NEGOCIABLES

### Estructura de archivos

```
edit/
  hyperframes/
    CLAUDE.md                    ← este archivo
    subtitles-comp/
      index.html                 ← composición de subtítulos
    overlay-comp/
      index.html                 ← composición hook + keywords + stickers
    motion-comp/
      index.html                 ← motion graphics (Fase 5)
  clips_hf/
    subtitles.webm               ← siempre WebM, nunca MP4
    overlay.webm
    motion.webm
  assets/
    stickers/
      stickers.json
      claude-logo.png
      chatgpt-logo.png
      [otros logos PNG con alpha]
```

### Reglas de renderizado

| Regla | Por qué |
|-------|---------|
| SIEMPRE `--format webm` para overlays | MP4/H264 no tiene canal alpha → rectángulo blanco |
| SIEMPRE verificar `pix_fmt=yuva420p` con ffprobe | Confirmar que el alpha existe |
| SIEMPRE `lint` después de CADA cambio | No acumular errores |
| SIEMPRE `preview` antes del render final | El render cuesta tiempo |
| NUNCA `--format mp4` para overlays | Sin excepción |

### Reglas de compositing con ffmpeg

```bash
# CORRECTO — incluir -vcodec libvpx-vp9 ANTES del -i del webm
ffmpeg -i edit/base_video.mp4 \
       -vcodec libvpx-vp9 -i edit/clips_hf/subtitles.webm \
  -filter_complex "[0:v][1:v]overlay=x=0:y=OFFSET_Y[vout]" \
  ...

# INCORRECTO — sin -vcodec libvpx-vp9 el alpha sale negro
ffmpeg -i edit/base_video.mp4 \
       -i edit/clips_hf/subtitles.webm \   # ← FALLA
  ...
```

### Reglas de GSAP

```javascript
// CORRECTO — siempre .to() con estado inicial en gsap.set()
gsap.set('#hook', { opacity: 0, y: -30 });
gsap.to('#hook', { opacity: 1, y: 0, duration: 0.4, ease: 'power3.out' });

// INCORRECTO — .from() + .set(opacity:0) no funciona
gsap.set('#hook', { opacity: 0 });
gsap.from('#hook', { opacity: 0, ... }); // ← from() anima DESDE el estado actual
```

### Reglas de data-track-index

```
data-track-index 1-19:   composición principal (video base, audio)
data-track-index 20-29:  keyword pills
data-track-index 30-39:  subtítulos karaoke
data-track-index 40+:    stickers
```

### Timeline anchor obligatorio

```javascript
// Al final de CADA timeline — evita black frame flash
tl.to({}, { duration: SLOT_DURATION }, 0);
```

---

## CÁLCULO DEL OFFSET_Y

**El canvas es 1080×1920 = mismo tamaño que el video.**  
**offset_y = 0. Siempre. Sin excepción.**

```bash
# El overlay cubre todo el video — posición 0,0
ffmpeg -i edit/base_video.mp4 \
       -vcodec libvpx-vp9 -i edit/clips_hf/subtitles.webm \
  -filter_complex "[0:v][1:v]overlay=x=0:y=0:format=auto[vout]" \
  ...
```

**NUNCA usar y=840 ni ningún otro offset.** Si el canvas es 1080×1920, el overlay
cubre exactamente el video y no necesita offset.

---

## FONT SIZE — VALORES VALIDADOS

| Elemento      | font-size | font-weight | Comportamiento                  |
|---------------|-----------|-------------|---------------------------------|
| Hook box      | 32px      | 700         | 0s→5s, luego desaparece (fade)  |
| Subtitle pill | 28px      | 600         | Karaoke, toda la duración       |
| Keyword pill  | 38px      | 800         | 2s por aparición                |
| Bottom        | 385px     | —           | Posición subtítulos             |

**Silence cut threshold: 500ms (0.5s)**
**Fase 2: detect_repetitions.py + revisión del agente del transcript**

**Estos valores son para canvas 1080×1920 = mismo tamaño que el video.**  
**offset_y = 0.** El canvas cubre todo el video. No hay conversiones.  
**NUNCA cambiar el canvas a otro tamaño. Si lo cambias, todo se rompe.**

---

## STICKERS — SISTEMA COMBINADO

### Inventario fijo (Duvan los pone manualmente)
- `robot-pixel.png` — mascota del canal, pixel art naranja
- Assets personalizados propios

### Inventario dinámico (el agente los descarga)
El agente busca y descarga PNGs con fondo transparente cuando no existen.  
Fuentes oficiales:
- Claude/Anthropic: anthropic.com/brand
- ChatGPT/OpenAI: openai.com/brand  
- Meta: about.meta.com/brand/resources
- Google: developers.google.com/identity/branding-guidelines
- TikTok: newsroom.tiktok.com/en-us/brand

**Después de descargar:** verificar alpha con Pillow (`img.mode == 'RGBA'`).  
**Si no tiene alpha:** aplicar remoción de fondo blanco con numpy.  
**Reportar siempre** qué descargó y de dónde.

### Formato stickers.json

```json
{
  "stickers": [
    {
      "id": "claude",
      "keywords": ["claude", "claude code", "anthropic"],
      "file": "claude-logo.png",
      "source": "auto",
      "size": 85,
      "position": "bottom-left"
    },
    {
      "id": "robot-pixel",
      "keywords": ["agente", "ia", "automatización", "bot", "sistema"],
      "file": "robot-pixel.png",
      "source": "manual",
      "size": 95,
      "position": "bottom-center"
    },
    {
      "id": "chatgpt",
      "keywords": ["chatgpt", "chat gpt", "openai", "gpt"],
      "file": "chatgpt-logo.png",
      "source": "auto",
      "size": 80,
      "position": "bottom-left"
    },
    {
      "id": "meta",
      "keywords": ["meta", "meta ads", "facebook ads", "fb ads"],
      "file": "meta-logo.png",
      "source": "auto",
      "size": 75,
      "position": "bottom-left"
    }
  ]
}
```

---

## ERRORES CONOCIDOS — NUNCA REPETIR

Estos errores ya ocurrieron. Leer antes de cada sesión.

| # | Error | Síntoma | Fix |
|---|-------|---------|-----|
| 1 | Video fuente equivocado | Subtítulos del video viejo | Confirmar que transcript y video coinciden antes de continuar |
| 2 | Overlay MP4 sin alpha | Rectángulo blanco sobre el video | SIEMPRE `--format webm` |
| 3 | Caché de intermedios | Video sale igual después de cambios | `rm -f edit/clips_graded/seg_*.mp4` antes de re-renderear |
| 4 | Ruta corrupta por `\f` | Error en rutas de archivo | SIEMPRE `Path() /` nunca f-string con backslash |
| 5 | Timestamps sin remap | Subtítulos desfasados | Transcribir el BASE no el fuente |
| 6 | Font-size 64px | Texto gigante | Usar valores validados de esta guía |
| 7 | Lint solo al final | Errores difíciles de rastrear | Lint después de CADA cambio |
| 8 | Skills HyperFrames no instalados | HTML inválido | `npx hyperframes skills` al inicio |
| 9 | Sin preview antes del render | Renders costosos fallidos | SIEMPRE preview antes del render final |
| 10 | VP9 alpha negro | Alpha no se decodifica | `-vcodec libvpx-vp9` antes del `-i` del webm |
| 11 | `gsap.from()` + `gsap.set(opacity:0)` | Elementos nunca aparecen | Usar `gsap.set()` + `gsap.to()` siempre |
| 12 | Font 17px invisible | Texto no se ve | Usar 25px para subtítulos (validado) |
| 13 | Bottom 100px | Texto en el borde | Usar 544px (medido del competidor) |
| 14 | Subtítulos demasiado abajo | Recuadro negro en borde | bottom mínimo: 150px dentro del canvas |
| 15 | Estilo sin consultar | Recuadro negro no deseado | SIEMPRE preguntar estilo antes de generar HTML |

---

## CHECKLIST DE INICIO DE SESIÓN

```
□ Leer project.md → confirmar video fuente activo
□ Leer ERRORS.md → decir en voz alta "Entendido, evitaré: X" para cada error
□ Leer este CLAUDE.md completo
□ Leer stickers.json → inventario de stickers disponibles
□ Verificar: npx hyperframes --version (debe responder)
□ Verificar: ffmpeg -version (debe responder)
□ Confirmar dimensiones del video: ffprobe → W x H
□ Calcular offset_y = H - 1080
```

---

## CHECKLIST DE CIERRE DE SESIÓN

```
□ ¿Cometí errores nuevos? → agregar a ERRORS.md
□ ¿Descargué stickers nuevos? → confirmar en stickers.json
□ ¿El pipeline quedó en qué fase?
□ Confirmar: "Sesión cerrada. Pipeline en fase X. ERRORS.md actualizado."
```
