# REGLA DE CANVAS — DEFINITIVA, NO NEGOCIABLE

## EL PROBLEMA QUE ESTO RESUELVE

Cada vez que el agente cambia el tamaño del canvas (1920×1080, 1080×1080, etc.),
TODOS los valores de CSS (font-size, bottom, padding) dejan de funcionar
porque la escala cambia. Esto ha causado 5+ iteraciones de prueba y error.

## LA REGLA

```
CANVAS = 1080 × 1920 px (vertical, IGUAL que el video final)
```

**Sin excepción. Sin variantes. Sin discusión.**

- Canvas width  = Video width  = 1080px
- Canvas height = Video height = 1920px
- 1px CSS = 1px en el video final
- offset_y = 0 (el canvas CUBRE todo el video)
- No hay conversiones. No hay escalas. No hay cálculos.

## VALORES CSS DEFINITIVOS (canvas 1080×1920)

Medidos del competidor el 2026-04-30 sobre imagen de referencia.

### Subtítulos karaoke

```css
.subtitles-container {
  position: absolute;
  bottom: 385px;           /* 20% desde abajo — MEDIDO */
  left: 0;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 5px;
  flex-wrap: wrap;
  padding: 0 80px;         /* márgenes laterales */
}

.word {
  background: rgba(255, 255, 255, 0.92);
  color: #111111;
  
  font-family: Inter, system-ui, -apple-system, sans-serif;
  font-size: 28px;         /* VALIDADO — aprobado por Duvan 2026-05-01 */
  font-weight: 600;        /* semibold, NO black */
  line-height: 1.0;
  
  padding: 4px 10px;       /* compacto como el competidor */
  border-radius: 5px;
  
  white-space: nowrap;
  display: inline-block;
}

.word.active {
  background: #111111;
  color: #ffffff;
}
```

### Hook box (parte superior)

```css
.hook-box {
  position: absolute;
  top: 110px;              /* ~5.7% desde arriba */
  left: 50%;
  transform: translateX(-50%);
  
  background: rgba(255, 255, 255, 0.95);
  color: #111111;
  
  font-family: Inter, system-ui, -apple-system, sans-serif;
  font-size: 32px;         /* VALIDADO — aprobado por Duvan 2026-05-01 */
  font-weight: 700;
  line-height: 1.3;
  text-align: center;
  
  padding: 12px 18px;
  border-radius: 12px;
  max-width: 82%;
  
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.20);
}
```

**Comportamiento del hook:** Aparece al segundo 0, desaparece a los 5s.
GSAP: entrada opacity 0→1 en 0.4s, salida opacity 1→0 en 0.3s a los 5s.

### Keyword pill

```css
.keyword-pill {
  position: absolute;
  top: 45%;
  left: 50%;
  transform: translateX(-50%) translateY(-50%);
  
  background: #111111;
  color: #ffffff;
  
  font-family: Inter, system-ui, -apple-system, sans-serif;
  font-size: 28px;         /* entre hook y subtitle */
  font-weight: 800;
  
  padding: 10px 20px;
  border-radius: 10px;
  white-space: nowrap;
  opacity: 0;
}
```

### Sticker

```css
.sticker {
  position: absolute;
  bottom: 200px;           /* encima de los subtítulos */
  opacity: 0;
}
.sticker img {
  width: 65px;
  height: 65px;
}
```

## COMPOSITING — SIN OFFSET

```bash
# Como el canvas = video, overlay va en x=0:y=0
ffmpeg -i edit/base_video.mp4 \
       -vcodec libvpx-vp9 -i edit/clips_hf/subtitles.webm \
  -filter_complex "[0:v][1:v]overlay=x=0:y=0:format=auto[vout]" \
  -map "[vout]" -map "0:a" \
  -c:v libx264 -preset slow -crf 18 \
  -c:a copy \
  edit/final_video.mp4
```

**overlay=x=0:y=0** — NO y=840. NO offset. El canvas cubre todo el video.

## TABLA DE REFERENCIA RÁPIDA

| Elemento     | font-size | font-weight | bottom/top    | padding    | Comportamiento         |
|-------------|-----------|-------------|---------------|------------|------------------------|
| Subtitle    | 28px      | 600         | bottom: 385px | 4px 10px   | Karaoke, toda la duración |
| Hook box    | 32px      | 700         | top: 110px    | 12px 18px  | 0s → 5s, luego desaparece |
| Keyword pill| 38px      | 800         | top: 45%      | 10px 20px  | 2s por aparición       |
| Sticker     | —         | —           | bottom: 200px | —          | 3s por aparición       |

## SI EL AGENTE INTENTA CAMBIAR EL CANVAS

Si el agente sugiere cambiar el canvas a otro tamaño:
1. RECHAZAR inmediatamente
2. Decir: "El canvas es 1080×1920. No se cambia. Lee REGLA_CANVAS.md."
3. Todos los valores CSS de este archivo dependen de ese canvas exacto

## CHECKLIST ANTES DE RENDERIZAR

```
□ Canvas en index.html dice: width: 1080px; height: 1920px
□ font-size subtitle = 28px
□ font-size hook = 32px
□ font-size keyword pill = 38px
□ bottom subtitle = 385px
□ hook desaparece a los 5s (tl.to opacity:0 en t=5s)
□ font-family incluye Inter (no Arial Black)
□ font-weight subtitle = 600 (no 700, no 800)
□ silence cut threshold = 500ms (0.5s)
□ Fase 2 incluye detect_repetitions.py antes de cortar
□ offset_y en ffmpeg = 0
□ -vcodec libvpx-vp9 antes del -i del webm
```
