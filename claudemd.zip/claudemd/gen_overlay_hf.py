"""
gen_overlay_hf.py — Generador del overlay visual HyperFrames
Genera: hook box fijo + keyword pills + stickers contextuales

Valores CSS medidos del competidor de referencia (2026-04-30):
    Hook font-size:     28px
    Hook padding:       16px 22px
    Hook border-radius: 14px
    Hook top:           5% (~96px en canvas 1080px)

Uso:
    python helpers/gen_overlay_hf.py \
        --transcript  edit/transcripts/video.json \
        --stickers    edit/assets/stickers/stickers.json \
        --hook-text   "Meta ADs lanza conexión oficial con Claude" \
        --duration    65.0 \
        --out         edit/hyperframes/overlay-comp/index.html
"""

import argparse
import json
from pathlib import Path


# ─── KEYWORDS QUE ACTIVAN PILLS ──────────────────────────────────────────────

KEYWORD_PILLS = {
    "claude":           "Claude",
    "claude code":      "Claude Code",
    "chatgpt":          "ChatGPT",
    "chat gpt":         "ChatGPT",
    "gpt-4":            "GPT-4",
    "gpt-5":            "GPT-5",
    "gpt":              "GPT",
    "meta ads":         "Meta ADs",
    "facebook ads":     "Facebook Ads",
    "fb ads":           "FB Ads",
    "instagram":        "Instagram",
    "tiktok":           "TikTok",
    "agente ia":        "Agente IA",
    "agente":           "Agente IA",
    "automatización":   "Automatización",
    "automatizacion":   "Automatización",
    "ugc":              "UGC",
    "freepik":          "Freepik",
    "ecommerce":        "Ecommerce",
    "whatsapp":         "WhatsApp",
    "notion":           "Notion",
    "make":             "Make.com",
    "n8n":              "n8n",
    "openai":           "OpenAI",
    "gemini":           "Gemini",
    "anthropic":        "Anthropic",
    "copilot":          "Copilot",
    "midjourney":       "Midjourney",
    "sora":             "Sora",
}


# ─── DETECCIÓN DE EVENTOS ─────────────────────────────────────────────────────

def detect_events(words: list, stickers_cfg: list) -> tuple[list, list]:
    """
    Detecta keyword_hits y sticker_moments en el transcript.
    Retorna (keyword_hits, sticker_moments).
    """
    keyword_hits   = []
    sticker_moments = []

    for i, word in enumerate(words):
        word_lower = word["text"].lower().strip(".,!?¡¿:;\"'")

        # Bigrama con la siguiente palabra
        if i < len(words) - 1:
            bigram = word_lower + " " + words[i + 1]["text"].lower().strip(".,!?¡¿:;\"'")
        else:
            bigram = word_lower

        # ─── Detectar pills ───
        matched_pill = None
        # Intentar bigramas primero (más específicos)
        for kw, display in KEYWORD_PILLS.items():
            if " " in kw and kw in bigram:
                matched_pill = display
                break
        # Si no, unigramas
        if not matched_pill:
            for kw, display in KEYWORD_PILLS.items():
                if " " not in kw and kw == word_lower:
                    matched_pill = display
                    break

        if matched_pill:
            keyword_hits.append({
                "start_s":    word["start"] / 1000,
                "duration_s": 2.0,
                "text":       matched_pill,
            })

        # ─── Detectar stickers ───
        for sticker in stickers_cfg:
            matched = False
            for kw in sticker["keywords"]:
                kw_lower = kw.lower()
                if " " in kw_lower and kw_lower in bigram:
                    matched = True
                    break
                if " " not in kw_lower and kw_lower == word_lower:
                    matched = True
                    break
            if matched:
                sticker_moments.append({
                    "start_s":    word["start"] / 1000,
                    "duration_s": 3.0,
                    "sticker_id": sticker["id"],
                    "file":       sticker["file"],
                    "size":       sticker.get("size", 85),
                    "position":   sticker.get("position", "bottom-left"),
                })

    # ─── Deduplicar ───
    def dedup(events, min_gap=3.0, key="text"):
        result = []
        last_by_key = {}
        for ev in sorted(events, key=lambda x: x["start_s"]):
            k = ev.get(key, "any")
            last_t = last_by_key.get(k, -999)
            if ev["start_s"] - last_t > min_gap:
                result.append(ev)
                last_by_key[k] = ev["start_s"]
        return result

    keyword_hits    = dedup(keyword_hits,    key="text")
    sticker_moments = dedup(sticker_moments, key="sticker_id")

    return keyword_hits, sticker_moments


# ─── GENERAR HTML ─────────────────────────────────────────────────────────────

def generate_overlay_html(
    hook_text: str,
    keyword_hits: list,
    sticker_moments: list,
    video_duration_s: float,
) -> str:

    # ─── Pills HTML ───
    pills_html = ""
    for i, hit in enumerate(keyword_hits):
        pills_html += f"""
  <!-- Pill: '{hit['text']}' @ {hit['start_s']:.2f}s -->
  <div class="keyword-pill clip"
       data-start="{hit['start_s']:.3f}"
       data-duration="{hit['duration_s']:.1f}"
       data-track-index="{20 + i}"
       id="pill-{i}">
    {hit['text']}
  </div>"""

    # ─── Stickers HTML ───
    stickers_html = ""
    for i, s in enumerate(sticker_moments):
        stickers_html += f"""
  <!-- Sticker: {s['sticker_id']} @ {s['start_s']:.2f}s -->
  <div class="sticker {s['position']} clip"
       data-start="{s['start_s']:.3f}"
       data-duration="{s['duration_s']:.1f}"
       data-track-index="{40 + i}">
    <img src="../../assets/stickers/{s['file']}"
         width="{s['size']}" height="{s['size']}"
         alt="{s['sticker_id']}">
  </div>"""

    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<style>
/* ─── BASE ────────────────────────────────────────────────────────────── */
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{
  width: 1080px;
  height: 1920px;
  overflow: hidden;
  background: transparent;
}}

/* ─── HOOK BOX — fijo todo el video ─────────────────────────────────── */
/* Valores medidos del competidor (2026-04-30)                           */
.hook-box {{
  position: absolute;
  top: 5%;                        /* ~96px en canvas 1080px */
  left: 50%;
  transform: translateX(-50%);
  
  background: rgba(255, 255, 255, 0.95);
  color: #111111;
  
  font-family: Inter, system-ui, -apple-system, sans-serif;
  font-size: 22px;               /* MEDIDO — canvas 1080×1920 */
  font-weight: 700;
  line-height: 1.3;
  letter-spacing: -0.01em;
  text-align: center;
  
  padding: 12px 18px;            /* MEDIDO — canvas 1080×1920 */
  border-radius: 12px;           /* MEDIDO */
  max-width: 78%;
  
  box-shadow: 0 3px 16px rgba(0, 0, 0, 0.22);
  
  /* Empieza invisible — GSAP lo anima */
  opacity: 0;
}}

/* ─── KEYWORD PILL ───────────────────────────────────────────────────── */
.keyword-pill {{
  position: absolute;
  top: 42%;
  left: 50%;
  transform: translateX(-50%) translateY(-50%);
  
  background: #111111;
  color: #ffffff;
  
  font-family: Inter, system-ui, -apple-system, sans-serif;
  font-size: 28px;
  font-weight: 800;
  line-height: 1.2;
  text-align: center;
  
  padding: 10px 20px;
  border-radius: 10px;
  white-space: nowrap;
  
  /* Empieza invisible — GSAP lo anima */
  opacity: 0;
}}

/* ─── STICKER ────────────────────────────────────────────────────────── */
.sticker {{
  position: absolute;
  bottom: 200px;           /* encima de los subtítulos (385px) */
  
  filter: drop-shadow(0 4px 12px rgba(0, 0, 0, 0.35));
  
  /* Empieza invisible — GSAP lo anima */
  opacity: 0;
}}

.sticker.bottom-left   {{ left: 6%; }}
.sticker.bottom-center {{ left: 50%; transform: translateX(-50%); }}
.sticker.bottom-right  {{ right: 6%; }}

.sticker img {{
  display: block;
}}
</style>
</head>
<body>

<!--
  Overlay visual — Hook + Keywords + Stickers
  Generado por gen_overlay_hf.py
  Canvas: 1080x1920px (vertical, 1:1 con video)
  Hook font: 28px (medido del competidor)
  Pills: {len(keyword_hits)} eventos detectados
  Stickers: {len(sticker_moments)} eventos detectados
  Duración: {video_duration_s:.1f}s
-->

<!-- HOOK BOX — aparece en segundo 0, se queda todo el video -->
<div class="hook-box" id="hook">{hook_text}</div>

<!-- KEYWORD PILLS — aparecen y desaparecen en su momento -->
{pills_html}

<!-- STICKERS — aparecen y desaparecen en su momento -->
{stickers_html}

<script>
(function() {{

  // ─── HOOK — entra en segundo 0 ─────────────────────────────────────
  // REGLA: siempre gsap.set() + gsap.to() — NUNCA solo gsap.from()
  // gsap.from() anima DESDE el estado actual y puede no funcionar.
  gsap.set('#hook', {{ opacity: 0, y: -30 }});
  gsap.to('#hook', {{
    opacity: 1,
    y: 0,
    duration: 0.4,
    ease: 'power3.out',
    delay: 0.1   // pequeño delay para que HyperFrames esté listo
  }});

  // ─── PILLS — cada una entra y sale en su momento ──────────────────
  document.querySelectorAll('.keyword-pill').forEach(function(el) {{
    var start = parseFloat(el.dataset.start || '0');
    var dur   = parseFloat(el.dataset.duration || '2');

    // Estado inicial
    gsap.set(el, {{ opacity: 0, y: 15, scale: 0.9 }});

    // Entrada
    gsap.to(el, {{
      opacity: 1,
      y: 0,
      scale: 1,
      duration: 0.3,
      ease: 'back.out(1.4)',
      delay: start
    }});

    // Salida
    gsap.to(el, {{
      opacity: 0,
      duration: 0.2,
      ease: 'power2.in',
      delay: start + dur - 0.2
    }});
  }});

  // ─── STICKERS — cada uno entra y sale en su momento ──────────────
  document.querySelectorAll('.sticker').forEach(function(el) {{
    var start = parseFloat(el.dataset.start || '0');
    var dur   = parseFloat(el.dataset.duration || '3');

    // Estado inicial
    gsap.set(el, {{ opacity: 0, scale: 0.7 }});

    // Entrada
    gsap.to(el, {{
      opacity: 1,
      scale: 1,
      duration: 0.35,
      ease: 'back.out(1.7)',
      delay: start
    }});

    // Salida
    gsap.to(el, {{
      opacity: 0,
      scale: 0.8,
      duration: 0.2,
      ease: 'power2.in',
      delay: start + dur - 0.2
    }});
  }});

  // ─── DURATION ANCHOR — evita black frame flash ────────────────────
  var tl = gsap.timeline();
  tl.to({{}}, {{ duration: {video_duration_s:.1f} }}, 0);

}})();
</script>
</body>
</html>
"""


# ─── MAIN ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Genera overlay visual HyperFrames")
    parser.add_argument("--transcript",  required=True,  help="Ruta al transcript JSON")
    parser.add_argument("--stickers",    required=True,  help="Ruta al stickers.json")
    parser.add_argument("--hook-text",   required=True,  help="Texto del hook box (máx 3 líneas)")
    parser.add_argument("--duration",    type=float, required=True, help="Duración del video en segundos")
    parser.add_argument("--out",         required=True,  help="Ruta de salida del index.html")
    args = parser.parse_args()

    # ─── Cargar datos ───
    transcript_path = Path(args.transcript)
    stickers_path   = Path(args.stickers)
    out_path        = Path(args.out)

    print(f"📂 Transcript:  {transcript_path}")
    print(f"📂 Stickers:    {stickers_path}")
    print(f"📂 Output:      {out_path}")
    print(f"📝 Hook text:   '{args.hook_text}'")
    print(f"⏱️  Duración:    {args.duration:.1f}s")

    if not transcript_path.exists():
        raise FileNotFoundError(f"Transcript no encontrado: {transcript_path}")
    if not stickers_path.exists():
        raise FileNotFoundError(f"stickers.json no encontrado: {stickers_path}")

    transcript  = json.loads(transcript_path.read_text(encoding="utf-8"))
    stickers_db = json.loads(stickers_path.read_text(encoding="utf-8"))

    words         = transcript.get("words", [])
    stickers_list = stickers_db.get("stickers", [])

    if not words:
        raise ValueError("El transcript no tiene palabras.")

    # ─── Detectar eventos ───
    keyword_hits, sticker_moments = detect_events(words, stickers_list)

    print(f"\n🎯 Pills detectadas:   {len(keyword_hits)}")
    for h in keyword_hits:
        print(f"   {h['start_s']:.2f}s → '{h['text']}'")

    print(f"\n🖼️  Stickers detectados: {len(sticker_moments)}")
    for s in sticker_moments:
        print(f"   {s['start_s']:.2f}s → {s['sticker_id']} ({s['file']})")

    # ─── Generar HTML ───
    html = generate_overlay_html(
        hook_text=args.hook_text,
        keyword_hits=keyword_hits,
        sticker_moments=sticker_moments,
        video_duration_s=args.duration,
    )

    # ─── Guardar ───
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")

    print(f"\n✅ HTML generado: {out_path}")
    print(f"\n⚡ Siguiente paso:")
    print(f"   cd {out_path.parent}")
    print(f"   npx hyperframes lint")
    print(f"   npx hyperframes preview")
    print(f"   npx hyperframes render --format webm --out ../../clips_hf/overlay.webm")
    print(f"   ffprobe -v quiet -show_streams ../../clips_hf/overlay.webm | grep pix_fmt")


if __name__ == "__main__":
    main()
