"""
gen_subtitles_hf.py — Generador de subtítulos HyperFrames
Valores CSS medidos directamente del competidor de referencia.

Uso:
    python helpers/gen_subtitles_hf.py \
        --transcript edit/transcripts/video.json \
        --edl        edit/edl_video.json \
        --out        edit/hyperframes/subtitles-comp/index.html \
        --words-per-cue 2 \
        --font-size 25 \
        --bottom 385 \
        --style competitor

Valores validados (medidos del competidor):
    font-size:  25px  → legible en teléfono, ni gigante ni invisible
    bottom:     385px → posición correcta en canvas 1080×1920
    padding:    6px 12px vertical/horizontal
    border-r:   6px
"""

import argparse
import json
from pathlib import Path


# ─── VALORES CSS MEDIDOS DEL COMPETIDOR ─────────────────────────────────────
# NO cambiar sin justificación y aprobación de Duvan.
# Medidos directamente de la imagen de referencia el 2026-04-30.

COMPETITOR_CSS = {
    "font_size":      28,    # px — VALIDADO, aprobado por Duvan 2026-05-01
    "bottom":         385,   # px — MEDIDO del competidor (20% desde abajo)
    "padding_v":      4,     # px vertical — compacto como el competidor
    "padding_h":      10,    # px horizontal
    "border_radius":  5,     # px
    "gap":            5,     # px entre palabras
    "canvas_w":       1080,  # FIJO — mismo que el video — NO CAMBIAR
    "canvas_h":       1920,  # FIJO — mismo que el video — NO CAMBIAR
}

SHADOW_CSS = {
    "font_size":  25,
    "bottom":     385,
    "padding_v":  4,
    "padding_h":  6,
}

# ─── ESTILOS DISPONIBLES ─────────────────────────────────────────────────────

def get_style_css(style: str, cfg: dict) -> str:
    """Retorna el bloque CSS para el estilo pedido."""
    
    fs   = cfg.get("font_size", COMPETITOR_CSS["font_size"])
    bot  = cfg.get("bottom",    COMPETITOR_CSS["bottom"])
    pv   = cfg.get("padding_v", COMPETITOR_CSS["padding_v"])
    ph   = cfg.get("padding_h", COMPETITOR_CSS["padding_h"])
    br   = cfg.get("border_radius", COMPETITOR_CSS["border_radius"])
    gap  = cfg.get("gap",       COMPETITOR_CSS["gap"])

    if style == "competitor":
        # Estilo medido del competidor — fondo blanco, texto negro bold
        return f"""
/* ─── SUBTÍTULOS ESTILO COMPETIDOR ───────────────────────────────────── */
/* Valores medidos directamente de la imagen de referencia (2026-04-30)  */
.subtitles-container {{
  position: absolute;
  bottom: {bot}px;
  left: 0;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: {gap}px;
  flex-wrap: wrap;
  padding: 0 60px;
}}

.word {{
  background: rgba(255, 255, 255, 0.93);
  color: #111111;
  font-family: Inter, system-ui, -apple-system, sans-serif;
  font-size: {fs}px;
  font-weight: 600;    /* semibold — NO black */
  line-height: 1.0;
  padding: {pv}px {ph}px;
  border-radius: {br}px;
  white-space: nowrap;
  display: inline-block;
}}

.word.active {{
  background: #111111;
  color: #ffffff;
}}
"""

    elif style == "shadow":
        # Estilo texto con sombra — sin recuadro, más limpio en fondos variables
        pv2 = cfg.get("padding_v", SHADOW_CSS["padding_v"])
        ph2 = cfg.get("padding_h", SHADOW_CSS["padding_h"])
        return f"""
/* ─── SUBTÍTULOS ESTILO SOMBRA ──────────────────────────────────────── */
.subtitles-container {{
  position: absolute;
  bottom: {bot}px;
  left: 0;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: {gap}px;
  flex-wrap: wrap;
  padding: 0 60px;
}}

.word {{
  background: transparent;
  color: #ffffff;
  font-family: 'Inter', 'Arial Black', 'Helvetica Neue', Arial, sans-serif;
  font-size: {fs}px;
  font-weight: 800;
  line-height: 1.0;
  padding: {pv2}px {ph2}px;
  white-space: nowrap;
  display: inline-block;
  text-shadow:
    0 0 8px rgba(0,0,0,0.95),
    0 1px 4px rgba(0,0,0,1),
    0 -1px 4px rgba(0,0,0,1),
    1px 0 4px rgba(0,0,0,1),
    -1px 0 4px rgba(0,0,0,1);
}}

.word.active {{
  color: #FFE135;
  text-shadow:
    0 0 12px rgba(0,0,0,1),
    0 2px 6px rgba(0,0,0,1),
    0 -2px 6px rgba(0,0,0,1);
}}
"""

    else:
        raise ValueError(f"Estilo desconocido: '{style}'. Usar 'competitor' o 'shadow'.")


# ─── REMAP DE TIMESTAMPS ─────────────────────────────────────────────────────

def remap_timestamps(words: list, edl: list) -> list:
    """
    Convierte timestamps del video fuente al timeline del video editado.
    Si el transcript ya es del base (transcribiste base_video.mp4), 
    esta función es un pass-through sin cambios.
    """
    remapped = []
    output_time = 0.0

    for segment in sorted(edl, key=lambda x: x.get("src_start", x.get("start", 0))):
        src_start = segment.get("src_start", segment.get("start", 0))
        src_end   = segment.get("src_end",   segment.get("end", 0))
        duration  = src_end - src_start

        for word in words:
            src_t = word["start"] / 1000
            if src_start <= src_t < src_end:
                output_t = output_time + (src_t - src_start)
                remapped.append({
                    **word,
                    "output_start_s": output_t,
                    "source_start_s": src_t,
                })

        output_time += duration

    return remapped


# ─── GENERAR CUES ────────────────────────────────────────────────────────────

def build_cues(words_remapped: list, words_per_cue: int = 2) -> list:
    """Agrupa palabras en cues de N palabras."""
    cues = []
    for i in range(0, len(words_remapped), words_per_cue):
        group = words_remapped[i : i + words_per_cue]
        if not group:
            continue

        start_s    = group[0]["output_start_s"]
        next_start = words_remapped[i + words_per_cue]["output_start_s"] \
                     if i + words_per_cue < len(words_remapped) else start_s + 2.0
        duration_s = next_start - start_s

        cues.append({
            "start_s":    start_s,
            "duration_s": duration_s,
            "words":      [w["text"] for w in group],
        })
    return cues


# ─── GENERAR HTML ────────────────────────────────────────────────────────────

def generate_html(cues: list, style_css: str, video_duration_s: float) -> str:
    
    # Generar divs de cues
    cues_html = ""
    for idx, cue in enumerate(cues):
        words_html = ""
        for w_idx, word in enumerate(cue["words"]):
            active_class = " active" if w_idx == len(cue["words"]) - 1 else ""
            words_html += f'      <span class="word{active_class}">{word}</span>\n'

        cues_html += f"""
  <div class="subtitles-container clip"
       data-start="{cue['start_s']:.3f}"
       data-duration="{cue['duration_s']:.3f}"
       data-track-index="{30 + (idx % 10)}"
       id="cue-{idx}">
{words_html}  </div>
"""

    return f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<style>
/* ─── BASE ────────────────────────────────────────────────────────────── */
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{
  width: 1080px;
  height: 1920px;
  overflow: hidden;
  background: transparent;
}}

{style_css}
</style>
</head>
<body>

<!-- 
  Subtítulos karaoke — {len(cues)} cues
  Generado por gen_subtitles_hf.py
  Canvas: 1080x1920px (vertical, 1:1 con video)
  Font: {COMPETITOR_CSS['font_size']}px (medido del competidor)
  Bottom: {COMPETITOR_CSS['bottom']}px (medido del competidor)
-->

{cues_html}

<script>
// Cada cue ya tiene data-start y data-duration
// HyperFrames los activa/desactiva automáticamente via el .clip class
// Solo añadir el duration anchor obligatorio

const tl = gsap.timeline();

// Duration anchor — evita black frame flash al final
tl.to({{}}, {{ duration: {video_duration_s:.1f} }}, 0);
</script>
</body>
</html>
"""


# ─── MAIN ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Genera subtítulos HyperFrames")
    parser.add_argument("--transcript",   required=True,  help="Ruta al transcript JSON (AssemblyAI)")
    parser.add_argument("--edl",          required=True,  help="Ruta al EDL JSON")
    parser.add_argument("--out",          required=True,  help="Ruta de salida del index.html")
    parser.add_argument("--words-per-cue",type=int, default=2, help="Palabras por cue (default: 2)")
    parser.add_argument("--font-size",    type=int, default=COMPETITOR_CSS["font_size"],
                        help=f"Font size en px (default: {COMPETITOR_CSS['font_size']}, medido del competidor)")
    parser.add_argument("--bottom",       type=int, default=COMPETITOR_CSS["bottom"],
                        help=f"Distancia desde abajo en px (default: {COMPETITOR_CSS['bottom']}, medido del competidor)")
    parser.add_argument("--style",        default="competitor",
                        choices=["competitor", "shadow"],
                        help="Estilo visual: competitor (recuadro blanco) o shadow (texto con sombra)")
    args = parser.parse_args()

    # ─── Cargar datos ───
    transcript_path = Path(args.transcript)
    edl_path        = Path(args.edl)
    out_path        = Path(args.out)

    print(f"📂 Transcript: {transcript_path}")
    print(f"📂 EDL:        {edl_path}")
    print(f"📂 Output:     {out_path}")

    if not transcript_path.exists():
        raise FileNotFoundError(f"Transcript no encontrado: {transcript_path}")
    if not edl_path.exists():
        raise FileNotFoundError(f"EDL no encontrado: {edl_path}")

    transcript = json.loads(transcript_path.read_text(encoding="utf-8"))
    edl        = json.loads(edl_path.read_text(encoding="utf-8"))

    words = transcript.get("words", [])
    if not words:
        raise ValueError("El transcript no tiene palabras. ¿Es el formato correcto de AssemblyAI?")

    # ─── Verificación básica ───
    first_ts = words[0]["start"] / 1000
    print(f"\n📝 Primeras 5 palabras del transcript:")
    for w in words[:5]:
        print(f"   {w['start']/1000:.2f}s  '{w['text']}'")

    if first_ts > 5.0:
        print(f"\n⚠️  ADVERTENCIA: El primer timestamp es {first_ts:.2f}s > 5s")
        print(f"   Esto puede indicar que transcribiste el video FUENTE en vez del BASE.")
        print(f"   Verificar con Duvan antes de continuar.")

    # ─── Obtener duración del EDL ───
    segments = edl if isinstance(edl, list) else edl.get("segments", [])
    total_duration = sum(
        s.get("src_end", s.get("end", 0)) - s.get("src_start", s.get("start", 0))
        for s in segments
    )
    print(f"\n⏱️  Duración total del EDL: {total_duration:.1f}s")

    # ─── Remap + cues ───
    words_remapped = remap_timestamps(words, segments)
    cues           = build_cues(words_remapped, args.words_per_cue)
    print(f"🎬 Cues generados: {len(cues)}")

    # ─── CSS con los valores del argumento ───
    cfg = {
        "font_size":     args.font_size,
        "bottom":        args.bottom,
        "padding_v":     COMPETITOR_CSS["padding_v"],
        "padding_h":     COMPETITOR_CSS["padding_h"],
        "border_radius": COMPETITOR_CSS["border_radius"],
        "gap":           COMPETITOR_CSS["gap"],
    }
    style_css = get_style_css(args.style, cfg)

    # ─── Generar HTML ───
    html = generate_html(cues, style_css, total_duration)

    # ─── Guardar ───
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding="utf-8")

    print(f"\n✅ HTML generado: {out_path}")
    print(f"   Cues: {len(cues)}")
    print(f"   Estilo: {args.style}")
    print(f"   Font-size: {args.font_size}px")
    print(f"   Bottom: {args.bottom}px")
    print(f"\n⚡ Siguiente paso:")
    print(f"   cd {out_path.parent}")
    print(f"   npx hyperframes lint")
    print(f"   npx hyperframes preview")
    print(f"   npx hyperframes render --format webm --out ../../clips_hf/subtitles.webm")


if __name__ == "__main__":
    main()
