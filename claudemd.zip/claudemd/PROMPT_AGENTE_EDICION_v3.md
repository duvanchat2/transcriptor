# PROMPT DEL AGENTE — Pipeline de edición de video
# Versión 3.0 — Con sistema visual del competidor + stickers combinados
# Dar esto al agente AL INICIO de cada sesión nueva

---

## PASO 0 — LECTURA OBLIGATORIA ANTES DE HACER CUALQUIER COSA

Lee estos archivos EN ORDEN. Confirma cada uno en voz alta antes de continuar.

```
1. edit/project.md               → video fuente exacto, rutas, estado actual del pipeline
2. edit/ERRORS.md                → di "Entendido, evitaré: [error]" por CADA error registrado
3. edit/hyperframes/CLAUDE.md    → sistema visual, CSS exacto, reglas de HyperFrames
4. edit/assets/stickers/stickers.json → inventario de stickers disponibles
```

Si alguno no existe → dímelo antes de continuar. No inventes rutas.

**Verificación de herramientas:**
```bash
npx hyperframes --version    # debe responder
ffmpeg -version | head -1    # debe responder
python -c "import PIL; print('Pillow OK')"
```

---

## EL PIPELINE — 5 FASES EN ORDEN ESTRICTO

```
FASE 1: Cortar silencios       → produce base_<video>.mp4
FASE 2: Transcribir            → produce transcripts/<video>.json
FASE 3: Subtítulos karaoke     → produce clips_hf/subtitles.webm
FASE 4: Overlay visual         → produce clips_hf/overlay.webm
         (hook + keywords + stickers)
FASE 5: Motion graphics        → produce final_<video>.mp4
```

**Regla de oro:** No saltes fases. No combines fases. 
Al terminar cada fase: sacar screenshot → mostrarlo → esperar confirmación.

---

## FASE 1 — CORTAR SILENCIOS

**Objetivo:** Eliminar silencios y tomas fallidas. Producir base limpio.

```bash
# PASO 1 — Verificar que transcript y video coinciden (error #1 conocido)
python3 - << 'EOF'
from pathlib import Path
import json

project = Path('edit/project.md').read_text(encoding='utf-8')
print("=== VIDEO FUENTE EN project.md ===")
for line in project.splitlines():
    if 'video' in line.lower() or 'fuente' in line.lower():
        print(f"  {line.strip()}")

transcripts = list(Path('edit/transcripts').glob('*.json'))
print(f"\n=== TRANSCRIPTS DISPONIBLES ===")
for t in transcripts:
    print(f"  {t.name}")
EOF
# Confirmar con Duvan: "El video fuente es X, el transcript es Y. ¿Son el mismo video?"
```

```bash
# PASO 2 — Obtener dimensiones reales (SIEMPRE antes de cualquier otra cosa)
ffprobe -v quiet -print_format json -show_streams "videos_editar/<video>.mp4" \
  | python3 -c "
import json, sys
s = json.load(sys.stdin)['streams'][0]
w, h = s['width'], s['height']
print(f'Dimensiones: {w}x{h}')
print(f'offset_y para overlay: 0 (canvas 1080x1920 = video)')
print(f'Font subtitle: 18px (medido del competidor)')
print(f'Bottom subtitle: 385px (medido del competidor)')
print(f'Font hook: 22px')
"
```

```bash
# PASO 3 — Cortar silencios
PYTHONIOENCODING=utf-8 python helpers/silence_cut.py "videos_editar/<video>.mp4"

# PASO 4 — Generar base limpia (sin subtítulos)
PYTHONIOENCODING=utf-8 python helpers/render.py \
  --edl edit/edl_<video>.json \
  --no-subtitles \
  --out edit/base_<video>.mp4
```

**Verificación obligatoria:**
```bash
ffmpeg -ss 3 -i edit/base_<video>.mp4 -vframes 1 -q:v 2 edit/check_fase1.jpg
```
→ Mostrar `check_fase1.jpg`. Esperar: _"¿Los cortes se ven bien?"_

---

## FASE 2 — TRANSCRIBIR

**Objetivo:** Transcripción word-level del video BASE (no del fuente original).

**REGLA CRÍTICA:** Siempre transcribir `base_<video>.mp4`, NUNCA el fuente.  
Los timestamps deben corresponder a la timeline del video ya editado.

```bash
# PASO 1 — Extraer audio del BASE (mono 16kHz)
ffmpeg -i edit/base_<video>.mp4 \
  -ac 1 -ar 16000 -sample_fmt s16 \
  edit/audio_<video>.wav

# PASO 2 — Transcribir con AssemblyAI
PYTHONIOENCODING=utf-8 python helpers/transcribe.py edit/audio_<video>.wav
# Output: edit/transcripts/<video>.json
```

**Verificación del transcript:**
```python
import json
from pathlib import Path

t = json.loads(Path('edit/transcripts/<video>.json').read_text(encoding='utf-8'))
words = t.get('words', [])
print("=== PRIMERAS 10 PALABRAS ===")
for w in words[:10]:
    print(f"  {w['start']/1000:.2f}s  '{w['text']}'")

# Verificar que el primer timestamp es < 5s (confirma que es el base)
if words[0]['start'] / 1000 > 5:
    print("⚠️  ADVERTENCIA: El primer timestamp es > 5s — ¿es el video fuente en vez del base?")
else:
    print("✅ Timestamps parecen del video base")
```

→ Mostrar output. Esperar: _"¿Estas son las primeras palabras del video?"_

**Si hay errores de reconocimiento** (ej: "GTP 5" en vez de "GPT-4"):  
→ Corregirlos manualmente en el JSON antes de continuar.

---

## FASE 3 — SUBTÍTULOS KARAOKE

**Objetivo:** Subtítulos animados al estilo del competidor — fondo blanco, texto negro bold.

### PASO 3A — Preguntar el estilo antes de generar

Antes de escribir una sola línea de HTML, preguntar a Duvan:

> "Para los subtítulos, ¿cuál prefieres?  
> **Opción A — Estilo competidor:** recuadro blanco con texto negro bold (el que medimos)  
> **Opción B — Solo sombra:** texto blanco sin recuadro, con sombra negra"

No asumir. Esperar respuesta.

### PASO 3B — Generar el HTML

```bash
PYTHONIOENCODING=utf-8 python helpers/gen_subtitles_hf.py \
  --transcript edit/transcripts/<video>.json \
  --edl        edit/edl_<video>.json \
  --out        edit/hyperframes/subtitles-comp/index.html \
  --words-per-cue 2 \
  --font-size 18 \
  --bottom 385 \
  --style competitor
```

**CSS exacto para Opción A (estilo competidor):**
```css
.subtitles-container {
  position: absolute;
  bottom: 385px;        /* MEDIDO — 20% desde abajo — no cambiar */
  left: 0;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 6px;
  flex-wrap: wrap;
  padding: 0 60px;
}

.word {
  background: rgba(255, 255, 255, 0.93);
  color: #111111;
  font-family: 'Inter', sans-serif;
  font-size: 18px;      /* MEDIDO del competidor — no cambiar sin justificación */
  font-weight: 600;
  line-height: 1.0;
  padding: 6px 12px;    /* MEDIDO del competidor */
  border-radius: 6px;   /* MEDIDO del competidor */
  white-space: nowrap;
}

.word.active {
  background: #111111;
  color: #ffffff;
}
```

**CSS exacto para Opción B (texto con sombra):**
```css
.subtitles-container {
  position: absolute;
  bottom: 385px;
  left: 0;
  width: 100%;
  display: flex;
  justify-content: center;
  gap: 6px;
  flex-wrap: wrap;
  padding: 0 60px;
}

.word {
  background: transparent;
  color: #ffffff;
  font-family: 'Inter', sans-serif;
  font-size: 18px;
  font-weight: 800;
  line-height: 1.0;
  padding: 4px 6px;
  text-shadow:
    0 0 8px rgba(0,0,0,0.95),
    0 1px 4px rgba(0,0,0,1),
    0 -1px 4px rgba(0,0,0,1);
}

.word.active {
  color: #FFE135;    /* amarillo karaoke — alternativa: #FF6B35 naranja */
  text-shadow:
    0 0 12px rgba(0,0,0,1),
    0 2px 6px rgba(0,0,0,1);
}
```

### PASO 3C — Lint y render

```bash
# LINT después de generar (y después de CADA cambio posterior)
cd edit/hyperframes/subtitles-comp
npx hyperframes lint
# Si hay errores → corregir → lint de nuevo → solo continuar con 0 errores

# PREVIEW antes del render
npx hyperframes preview
# Abrir http://localhost:3002
# Verificar: ¿subtítulos visibles? ¿tamaño correcto? ¿posición correcta?
# Hacer scrubbing en segundo 3, 10 y 30

# RENDER — SIEMPRE WebM, NUNCA MP4
npx hyperframes render --format webm --out ../../clips_hf/subtitles.webm

# VERIFICAR ALPHA — obligatorio antes de compositar
ffprobe -v quiet -show_streams edit/clips_hf/subtitles.webm | grep pix_fmt
# Debe mostrar: pix_fmt=yuva420p
# Si NO muestra yuva420p → NO compositar → el alpha está roto → investigar
```

### PASO 3D — Compositar (offset_y = 0 SIEMPRE)

**El canvas es 1080×1920 = mismo tamaño que el video. offset_y = 0.**

```bash
# BORRAR intermedios antes de compositar (evita caché)
rm -f edit/clips_graded/seg_*.mp4
rm -f edit/prenorm.mp4

# COMPOSITAR — incluir -vcodec libvpx-vp9 ANTES del -i del webm
ffmpeg -i edit/base_<video>.mp4 \
       -vcodec libvpx-vp9 -i edit/clips_hf/subtitles.webm \
  -filter_complex "[0:v][1:v]overlay=x=0:y=0[vout];[0:a]loudnorm=I=-14:TP=-1:LRA=11[aout]" \
  -map "[vout]" -map "[aout]" \
  -c:v libx264 -preset slow -crf 18 \
  -c:a aac -b:a 192k \
  -movflags +faststart \
  edit/final_subs_<video>.mp4
```

**Verificación Fase 3:**
```bash
ffmpeg -ss 5 -i edit/final_subs_<video>.mp4 -vframes 1 -q:v 2 edit/check_fase3.jpg
```

**Auto-revisión con video-vision:**
```
/watch-video edit/final_subs_<video>.mp4 "Revisa estos 4 puntos y da veredicto APROBADO o RECHAZADO:
1. ¿El texto de los subtítulos es legible y tiene el tamaño correcto (ni gigante ni invisible)?
2. ¿Los subtítulos están en la zona inferior pero NO pegados al borde negro?
3. ¿El recuadro detrás del texto se integra bien con el video?
4. ¿Los subtítulos aparecen sincronizados con el audio (verificar segundo 3, 10 y 30)?"
```

→ Mostrar `check_fase3.jpg`. Si video-vision dice RECHAZADO → corregir → re-renderear → nueva revisión.  
→ **Solo avanzar a Fase 4 con APROBADO.**

---

## FASE 4 — OVERLAY VISUAL (HOOK + KEYWORDS + STICKERS)

**Objetivo:** Agregar los 3 elementos visuales del estilo del competidor:
1. Hook box — fijo en la parte superior todo el video
2. Keyword pills — aparecen cuando se menciona un concepto clave
3. Stickers — aparecen cuando se menciona el producto/herramienta

### PASO 4A — Preparar el hook text

Antes de generar el HTML, preguntar a Duvan:
> "¿Cuál es el texto del hook box que va arriba?  
> Máximo 3 líneas. Es el título del video que aparece todo el tiempo."

Si Duvan ya lo definió en el guión → usar ese texto exacto.

### PASO 4B — Preparar stickers

```bash
# Verificar stickers disponibles
cat edit/assets/stickers/stickers.json

# Para cada sticker que falta → buscar y descargar
# Ver sección STICKERS en CLAUDE.md para fuentes oficiales

# Verificar alpha de stickers
python3 - << 'EOF'
from pathlib import Path
from PIL import Image

stickers_dir = Path('edit/assets/stickers')
for png in stickers_dir.glob('*.png'):
    try:
        img = Image.open(png)
        has_alpha = 'A' in img.mode or img.mode == 'RGBA'
        print(f"{'✅' if has_alpha else '❌'} {png.name}: modo={img.mode}, tamaño={img.size}")
    except Exception as e:
        print(f"❌ {png.name}: ERROR — {e}")
EOF
```

**Si un sticker no tiene alpha:** aplicar remoción de fondo blanco:
```python
from PIL import Image
import numpy as np
from pathlib import Path

def remove_white_bg(filepath):
    img = Image.open(filepath).convert('RGBA')
    data = np.array(img)
    # Remover píxeles muy claros (fondo blanco)
    white_mask = (data[:,:,0] > 240) & (data[:,:,1] > 240) & (data[:,:,2] > 240)
    data[white_mask, 3] = 0
    result = Image.fromarray(data)
    result.save(filepath)
    print(f"✅ Alpha aplicado a {filepath}")

remove_white_bg('edit/assets/stickers/nombre.png')
```

### PASO 4C — Detectar keywords y sticker moments del transcript

```python
import json
from pathlib import Path

# ─── CONFIGURACIÓN ───
KEYWORD_PILLS = {
    "claude":           "Claude",
    "claude code":      "Claude Code",
    "chatgpt":          "ChatGPT",
    "chat gpt":         "ChatGPT",
    "gpt":              "GPT",
    "meta ads":         "Meta ADs",
    "facebook ads":     "Facebook Ads",
    "fb ads":           "FB Ads",
    "instagram":        "Instagram",
    "tiktok":           "TikTok",
    "agente":           "Agente IA",
    "automatización":   "Automatización",
    "ugc":              "UGC",
    "freepik":          "Freepik",
    "ecommerce":        "Ecommerce",
    "whatsapp":         "WhatsApp",
    "notion":           "Notion",
    "make":             "Make.com",
    "n8n":              "n8n",
    "openai":           "OpenAI",
    "gemini":           "Gemini",
}

# ─── CARGAR DATOS ───
transcript = json.loads(Path('edit/transcripts/<video>.json').read_text(encoding='utf-8'))
stickers_cfg = json.loads(Path('edit/assets/stickers/stickers.json').read_text(encoding='utf-8'))
words = transcript.get('words', [])

# ─── DETECTAR EVENTOS ───
keyword_hits = []
sticker_moments = []

for i, word in enumerate(words):
    word_lower = word['text'].lower().strip('.,!?¡¿')
    
    # Verificar pills (también bigramas con la palabra siguiente)
    context = word_lower
    if i < len(words) - 1:
        context_2 = word_lower + ' ' + words[i+1]['text'].lower().strip('.,!?¡¿')
    else:
        context_2 = word_lower
    
    for kw, display in KEYWORD_PILLS.items():
        if kw in context or kw in context_2:
            keyword_hits.append({
                'start_s': word['start'] / 1000,
                'duration_s': 2.0,
                'text': display
            })
            break
    
    # Verificar stickers
    for sticker in stickers_cfg['stickers']:
        for kw in sticker['keywords']:
            if kw in context or kw in context_2:
                sticker_moments.append({
                    'start_s': word['start'] / 1000,
                    'duration_s': 3.0,
                    'sticker_id': sticker['id'],
                    'file': sticker['file'],
                    'size': sticker['size'],
                    'position': sticker['position']
                })
                break

# ─── DEDUPLICAR (min 3s entre eventos del mismo tipo) ───
def dedup(events, min_gap=3.0, key='text'):
    result = []
    last_by_key = {}
    for ev in sorted(events, key=lambda x: x['start_s']):
        k = ev.get(key, 'any')
        last = last_by_key.get(k, -999)
        if ev['start_s'] - last > min_gap:
            result.append(ev)
            last_by_key[k] = ev['start_s']
    return result

keyword_hits = dedup(keyword_hits, key='text')
sticker_moments = dedup(sticker_moments, key='sticker_id')

# ─── REPORTE ───
print(f"Pills detectadas: {len(keyword_hits)}")
for h in keyword_hits:
    print(f"  {h['start_s']:.2f}s → '{h['text']}'")

print(f"\nStickers detectados: {len(sticker_moments)}")
for s in sticker_moments:
    print(f"  {s['start_s']:.2f}s → {s['sticker_id']}")

# Guardar para usar en el siguiente paso
Path('edit/overlay_events.json').write_text(
    json.dumps({'keyword_hits': keyword_hits, 'sticker_moments': sticker_moments}, indent=2),
    encoding='utf-8'
)
print("\n✅ Guardado en edit/overlay_events.json")
```

→ Mostrar el reporte. Preguntar a Duvan: _"¿Se detectaron las keywords correctas?"_

### PASO 4D — Generar el HTML del overlay

```python
from pathlib import Path
import json

def generate_overlay_html(hook_text, keyword_hits, sticker_moments, video_duration_s):
    
    # ─── PILLS HTML ───
    pills_html = ""
    for i, hit in enumerate(keyword_hits):
        pills_html += f"""
  <div class="keyword-pill clip"
       data-start="{hit['start_s']:.3f}"
       data-duration="{hit['duration_s']:.1f}"
       data-track-index="{20 + i}"
       id="pill-{i}">
    {hit['text']}
  </div>"""
    
    # ─── STICKERS HTML ───
    stickers_html = ""
    for i, s in enumerate(sticker_moments):
        stickers_html += f"""
  <div class="sticker {s['position']} clip"
       data-start="{s['start_s']:.3f}"
       data-duration="{s['duration_s']:.1f}"
       data-track-index="{40 + i}">
    <img src="../../assets/stickers/{s['file']}"
         width="{s['size']}" height="{s['size']}"
         style="filter: drop-shadow(0 4px 12px rgba(0,0,0,0.35));">
  </div>"""
    
    # ─── HTML COMPLETO ───
    html = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.2/gsap.min.js"></script>
<style>
* {{ margin: 0; padding: 0; box-sizing: border-box; }}
body {{ width: 1920px; height: 1080px; overflow: hidden; background: transparent; }}

/* ─── HOOK BOX ─── */
.hook-box {{
  position: absolute;
  top: 5%;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(255, 255, 255, 0.95);
  color: #111111;
  font-family: 'Inter', sans-serif;
  font-size: 28px;
  font-weight: 800;
  line-height: 1.3;
  letter-spacing: -0.01em;
  text-align: center;
  padding: 16px 22px;
  border-radius: 14px;
  max-width: 78%;
  box-shadow: 0 3px 16px rgba(0, 0, 0, 0.22);
  opacity: 0;
}}

/* ─── KEYWORD PILL ─── */
.keyword-pill {{
  position: absolute;
  top: 42%;
  left: 50%;
  transform: translateX(-50%) translateY(-50%);
  background: #111111;
  color: #ffffff;
  font-family: 'Inter', sans-serif;
  font-size: 38px;
  font-weight: 800;
  line-height: 1.2;
  text-align: center;
  padding: 14px 26px;
  border-radius: 12px;
  white-space: nowrap;
  opacity: 0;
}}

/* ─── STICKER ─── */
.sticker {{
  position: absolute;
  bottom: 9%;
  opacity: 0;
  filter: drop-shadow(0 4px 12px rgba(0,0,0,0.35));
}}
.sticker.bottom-left   {{ left: 6%; }}
.sticker.bottom-center {{ left: 50%; transform: translateX(-50%); }}
.sticker.bottom-right  {{ right: 6%; }}
</style>
</head>
<body>

<!-- HOOK BOX — fijo todo el video -->
<div class="hook-box" id="hook">{hook_text}</div>

<!-- KEYWORD PILLS -->
{pills_html}

<!-- STICKERS -->
{stickers_html}

<script>
const tl = gsap.timeline();

// Hook: entrada en segundo 0
gsap.set('#hook', {{ opacity: 0, y: -30 }});
gsap.to('#hook', {{ opacity: 1, y: 0, duration: 0.4, ease: 'power3.out', delay: 0.1 }});

// Pills: cada una entra y sale en su momento
document.querySelectorAll('.keyword-pill').forEach(function(el) {{
  const start = parseFloat(el.dataset.start || 0);
  const dur = parseFloat(el.dataset.duration || 2);
  gsap.set(el, {{ opacity: 0, y: 15, scale: 0.9 }});
  gsap.to(el, {{ opacity: 1, y: 0, scale: 1, duration: 0.3, ease: 'back.out(1.4)', delay: start }});
  gsap.to(el, {{ opacity: 0, duration: 0.2, ease: 'power2.in', delay: start + dur - 0.2 }});
}});

// Stickers: cada uno entra y sale en su momento
document.querySelectorAll('.sticker').forEach(function(el) {{
  const start = parseFloat(el.dataset.start || 0);
  const dur = parseFloat(el.dataset.duration || 3);
  gsap.set(el, {{ opacity: 0, scale: 0.7 }});
  gsap.to(el, {{ opacity: 1, scale: 1, duration: 0.35, ease: 'back.out(1.7)', delay: start }});
  gsap.to(el, {{ opacity: 0, scale: 0.8, duration: 0.2, ease: 'power2.in', delay: start + dur - 0.2 }});
}});

// Duration anchor obligatorio — evita black frame flash
tl.to({{}}, {{ duration: {video_duration_s} }}, 0);
</script>
</body>
</html>"""
    
    out_path = Path('edit/hyperframes/overlay-comp/index.html')
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(html, encoding='utf-8')
    print(f"✅ overlay index.html generado en {out_path}")

# ─── EJECUTAR ───
events = json.loads(Path('edit/overlay_events.json').read_text(encoding='utf-8'))

# IMPORTANTE: preguntar el hook_text a Duvan antes de llamar esta función
HOOK_TEXT = "PONER AQUÍ EL TEXTO DEL HOOK"

# Obtener duración del video
import subprocess
result = subprocess.run(
    ['ffprobe','-v','quiet','-print_format','json','-show_streams','edit/base_<video>.mp4'],
    capture_output=True, text=True
)
streams = json.loads(result.stdout)['streams']
duration = float(next(s for s in streams if s.get('codec_type') == 'video')['duration'])

generate_overlay_html(
    hook_text=HOOK_TEXT,
    keyword_hits=events['keyword_hits'],
    sticker_moments=events['sticker_moments'],
    video_duration_s=duration
)
```

### PASO 4E — Lint, preview y render

```bash
# LINT — obligatorio, después de generar y de CADA cambio
cd edit/hyperframes/overlay-comp
npx hyperframes lint
# 0 errores antes de continuar

# PREVIEW — obligatorio antes del render
npx hyperframes preview
# Verificar en http://localhost:3002:
# □ ¿El hook box aparece arriba y se queda?
# □ ¿Las pills aparecen en el momento correcto?
# □ ¿Los stickers están en la posición correcta?
# □ ¿Los stickers tienen fondo transparente (sin rectángulo blanco)?

# RENDER — SIEMPRE WebM
npx hyperframes render --format webm --out ../../clips_hf/overlay.webm

# VERIFICAR ALPHA
ffprobe -v quiet -show_streams edit/clips_hf/overlay.webm | grep pix_fmt
# Debe: yuva420p
```

### PASO 4F — Compositar overlay

```bash
# BORRAR intermedios antes
rm -f edit/clips_graded/seg_*.mp4

# COMPOSITAR con -vcodec libvpx-vp9
ffmpeg -i edit/final_subs_<video>.mp4 \
       -vcodec libvpx-vp9 -i edit/clips_hf/overlay.webm \
  -filter_complex "[0:v][1:v]overlay=x=0:y=0[vout]" \
  -map "[vout]" -map "0:a" \
  -c:v libx264 -preset slow -crf 18 \
  -c:a copy \
  edit/final_overlay_<video>.mp4
```

**Verificación Fase 4:**
```bash
ffmpeg -ss 1  -i edit/final_overlay_<video>.mp4 -vframes 1 -q:v 2 edit/check_hook.jpg
ffmpeg -ss 8  -i edit/final_overlay_<video>.mp4 -vframes 1 -q:v 2 edit/check_pill.jpg
ffmpeg -ss 15 -i edit/final_overlay_<video>.mp4 -vframes 1 -q:v 2 edit/check_sticker.jpg
```

**Auto-revisión con video-vision:**
```
/watch-video edit/final_overlay_<video>.mp4 "Revisa estos 5 puntos y da veredicto APROBADO o RECHAZADO:
1. ¿El hook box es visible y legible en la parte superior? ¿El texto cabe bien?
2. ¿Las keyword pills aparecen en el momento correcto y desaparecen bien?
3. ¿Los stickers son visibles sin tapar la cara del presentador?
4. ¿Los stickers tienen fondo transparente (sin rectángulo blanco alrededor)?
5. ¿Los subtítulos siguen visibles debajo del hook?"
```

→ Solo avanzar a Fase 5 con APROBADO.

---

## FASE 5 — MOTION GRAPHICS

**Objetivo:** Agregar animaciones al estilo may-shorts-18/19 del student-kit.  
Referencia primaria: `video-projects/may-shorts-19/`

*(El input de esta fase es `final_overlay_<video>.mp4` en lugar de `final_subs_<video>.mp4`)*

### Qué crear (en este orden):

1. **Lower third** — nombre + handle, bottom-left, entra en segundo 1.5, dura 3s
2. **Transiciones entre secciones** — `npx hyperframes add flash-through-white`
3. **CTA final** — últimos 3s — `npx hyperframes add instagram-follow`

```bash
# Crear estructura
mkdir -p edit/hyperframes/motion-comp/compositions
mkdir -p edit/hyperframes/motion-comp/assets

# Copiar meta.json de referencia
cp video-projects/may-shorts-19/meta.json edit/hyperframes/motion-comp/meta.json

# Lint después de CADA cambio
cd edit/hyperframes/motion-comp
npx hyperframes lint

# Preview antes del render
npx hyperframes preview

# Render
npx hyperframes render --out ../../clips_hf/motion.webm

# Compositar sobre final_overlay
ffmpeg -i edit/final_overlay_<video>.mp4 \
       -vcodec libvpx-vp9 -i edit/clips_hf/motion.webm \
  -filter_complex "[0:v][1:v]overlay=x=0:y=0[vout]" \
  -map "[vout]" -map "0:a" \
  -c:v libx264 -preset slow -crf 18 \
  -c:a copy \
  edit/final_<video>.mp4
```

**Verificación final:**
```bash
ffmpeg -ss 1  -i edit/final_<video>.mp4 -vframes 1 -q:v 2 edit/check_final_hook.jpg
ffmpeg -ss 10 -i edit/final_<video>.mp4 -vframes 1 -q:v 2 edit/check_final_mid.jpg
ffmpeg -ss 58 -i edit/final_<video>.mp4 -vframes 1 -q:v 2 edit/check_final_cta.jpg
```

**Auto-revisión final:**
```
/watch-video edit/final_<video>.mp4 "Revisión final completa. Veredicto APROBADO o RECHAZADO:
1. ¿Hook box visible y legible arriba durante todo el video?
2. ¿Subtítulos bien posicionados, tamaño correcto, sincronizados?
3. ¿Keywords pills aparecen en los momentos correctos?
4. ¿Stickers sin rectángulo blanco, bien posicionados?
5. ¿CTA final visible en los últimos 3 segundos?
6. ¿Hay frames negros o parpadeos entre escenas?"
```

---

## REGLA DE AUTO-REVISIÓN — SIN EXCEPCIÓN

**Después de cada render, ANTES de reportar nada:**

1. Correr `/watch-video` con las preguntas específicas de esa fase
2. Si veredicto = RECHAZADO → identificar el problema exacto → corregir → re-renderear → nueva revisión
3. Si después de 3 intentos sigue RECHAZADO en el mismo punto → escalar a Duvan con el error específico
4. **Solo contactar a Duvan cuando el veredicto es APROBADO**

---

## CUANDO COMETAS UN ERROR

Antes de corregirlo:

1. Para lo que estás haciendo.
2. Agrega entrada a `edit/ERRORS.md`:
```markdown
## [FECHA] — [TÍTULO CORTO]
**Qué pasó:** 
**Por qué pasó:** 
**Fix exacto:** 
**Regla nueva:** 
```
3. Di en voz alta: "Cometí el error X. La regla nueva es Y."
4. Corrige.

---

## REGLAS NO NEGOCIABLES — RESUMEN

| Regla | Consecuencia si no se cumple |
|-------|------------------------------|
| Leer CLAUDE.md antes de empezar | Errores conocidos se repiten |
| Confirmar que transcript = video correcto | Subtítulos del video equivocado |
| Transcribir BASE, no fuente | Timestamps desfasados |
| Siempre `--format webm` para overlays | Rectángulo blanco tapa el video |
| `-vcodec libvpx-vp9` antes del `-i` del webm | Alpha sale negro |
| `pix_fmt=yuva420p` verificado antes de compositar | Alpha roto no detectado |
| Borrar `clips_graded/` antes de re-renderear | Video sale igual aunque cambié el estilo |
| `Path()` siempre, nunca backslash en f-strings | Ruta corrupta por `\f` |
| Lint después de CADA cambio al .html | Errores acumulados difíciles de rastrear |
| Preview antes de render final | Renders costosos fallidos |
| `gsap.set()` + `gsap.to()` — nunca solo `.from()` | Elementos nunca aparecen |
| Font subtitle = 18px | Ni gigante ni invisible |
| Bottom subtitle = 385px | Subtítulos en posición correcta |
| Font hook = 28px | Texto del hook proporcional |
| Preguntar estilo de subtítulos a Duvan | Recuadro no deseado |
| Preguntar hook text a Duvan | Texto equivocado en el overlay |
| Screenshot/video-vision después de cada fase | Declarar éxito sin ver el resultado |
| `data-track-index >= 20` para pills | Conflicto de capas |
| `data-track-index >= 30` para subtítulos | Conflicto de capas |
| `data-track-index >= 40` para stickers | Conflicto de capas |
| Timeline anchor al final de cada tl | Black frame flash |

---

## AL CERRAR LA SESIÓN

```
1. ¿Cometí errores nuevos esta sesión? → agregar a ERRORS.md
2. ¿Descargué stickers nuevos? → verificar que stickers.json está actualizado
3. ¿El pipeline quedó en qué fase?
4. Confirmar: "Sesión cerrada. Pipeline en fase [X]. ERRORS.md actualizado."
```
