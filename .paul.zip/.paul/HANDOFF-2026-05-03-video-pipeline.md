# HANDOFF — Pipeline de Edicion de Video Autonomo
**Fecha:** 2026-05-03  
**Proyecto:** `C:/Users/duvan/OneDrive/Documentos/transcriptor/`  
**Tarea original:** Procesar video1.MP4 y video2.MP4 de forma completamente autonoma (5 fases cada uno)

---

## CONTEXTO DEL PROYECTO

Canal: **Duvan — IA aplicada a Marketing y Ecommerce latinoamericano**  
Formato: Videos verticales **1080x1920px** (Reels, TikTok, Shorts)  
Pipeline: 5 fases en orden estricto — silence cut → transcripcion → subtitulos → overlay → composite

Archivos de reglas que DEBEN leerse antes de actuar:
- `C:/Users/duvan/OneDrive/Documentos/transcriptor/claudemd/CLAUDE.md`
- `C:/Users/duvan/OneDrive/Documentos/transcriptor/edit/hyperframes/CLAUDE.md`
- `C:/Users/duvan/OneDrive/Documentos/transcriptor/edit/ERRORS.md`

---

## ESTADO ACTUAL POR VIDEO

### VIDEO 1 — `videos_editar/edit/video1.MP4`

| Fase | Estado | Archivo resultado |
|------|--------|-------------------|
| Fase 1: Silence cut (500ms) | ✅ DONE | `videos_editar/edit/base_video1.mp4` (97.37s) |
| Fase 2: Transcripcion + detect_repetitions | ✅ DONE | `edit/transcripts/new_base_video1.json` (284 palabras) |
| Fase 2b: Video limpio (content cuts) | ✅ DONE | `videos_editar/edit/new_base_video1.mp4` (86.367s) |
| Fase 3: Subtitulos HTML | ✅ DONE | `edit/hyperframes/subtitles-comp/index.html` |
| Fase 3: Subtitulos WebM render | ❌ BLOQUEADO | Render falla — ver problema abajo |
| Fase 4: Overlay HTML | ✅ DONE | `edit/hyperframes/overlay-comp/index.html` |
| Fase 4: Overlay WebM render | ⚠️ PARCIAL | `edit/hyperframes/overlay-comp/overlay_v1.webm` — **SIN ALPHA** (pix_fmt=yuv420p, debe ser yuva420p) |
| Fase 5: Composite final | ❌ PENDIENTE | — |
| Frames check | ❌ PENDIENTE | check_v1_hook.jpg, check_v1_mid.jpg, check_v1_sub.jpg |

### VIDEO 2 — `videos_editar/edit/video2.MP4`

| Fase | Estado |
|------|--------|
| Todas las fases | ❌ SIN INICIAR |
| Duracion fuente | 140.13s |

---

## PROBLEMA BLOQUEANTE: RENDERS HYPERFRAMES FALLANDO

### Problema 1 — subtitles-comp render falla
- El proceso llega a 70% (frame capture completo) y luego falla en encoding
- `video-only.webm` a veces se crea en el work dir pero incompleto
- Exit code 1 sin mensaje de error claro
- **Hipotesis:** Posible timeout o memory issue con 2592 frames

**Workaround probado que NO funciono:** `--workers 1`

**Workaround a probar primero:**
```bash
cd "C:/Users/duvan/OneDrive/Documentos/transcriptor/edit/hyperframes/subtitles-comp"
# Intentar con quality draft para ver si es un problema de recursos
npx hyperframes render --format webm --quality draft -o subtitles_v1.webm .
```

**Workaround alternativo (si hyperframes sigue fallando):** Dado que los subtitulos son elementos CSS/GSAP puros sin video embebido, el render deberia funcionar. Si sigue fallando, intentar:
```bash
npx hyperframes render --format webm --quality draft --workers 1 -o subtitles_v1.webm .
```

### Problema 2 — overlay_v1.webm sin canal alpha
- `ffprobe` confirma: `pix_fmt=yuv420p` (debe ser `yuva420p`)
- El archivo existe en: `edit/hyperframes/overlay-comp/overlay_v1.webm`
- **Causa probable:** HyperFrames renderizo sin transparencia
- **Fix:** Re-renderizar overlay con `--format webm` y verificar alpha despues

**Verificacion de alpha:**
```bash
ffprobe -v quiet -show_entries stream=pix_fmt -of default=noprint_wrappers=1 archivo.webm
# Debe decir: pix_fmt=yuva420p
```

---

## ESPECIFICACIONES CSS VALIDADAS (NO CAMBIAR)

```
Canvas:          1080x1920px (SIEMPRE — nunca cambiar)
offset_y:        0 (siempre — el canvas cubre todo el video)

Hook box:        font-size: 32px, font-weight: 700
                 top: 110px, background: rgba(255,255,255,0.95)
                 Aparece 0s, DESAPARECE a los 5s (fade out)
                 
Subtitulos:      font-size: 28px, font-weight: 600
                 bottom: 385px, background: rgba(255,255,255,0.93)
                 .active { background: #111111; color: #fff }
                 
Keyword pill:    font-size: 38px, font-weight: 800, background: #111111
                 top: 42%, dura 2s por aparicion
```

---

## GSAP PATTERN (CRITICO — NO USAR from())

```javascript
// CORRECTO
gsap.set('#hook', { opacity: 0, y: -30 });
tl.to('#hook', { opacity: 1, y: 0, duration: 0.4, ease: 'power3.out' }, 0.1);
tl.to('#hook', { opacity: 0, duration: 0.3, ease: 'power2.in' }, 5.0); // desaparece a 5s
// Al final siempre:
tl.to({}, { duration: DURACION_VIDEO }, 0);
window.__timelines["nombre-comp"] = tl;
```

---

## CONTENIDO VIDEO 1

**Hook text** (ya en el HTML): `"La paradoja de los negocios<br>con IA ahora mismo"`

**Transcript opening:** "Esta es la paradoja que tiene cualquier negocio ahora con la inteligencia artificial..."

**Nota:** La transcripcion dice "Cloud" donde deberia decir "Claude" (error del ASR). El video es sobre Claude/Anthropic.

**Keyword pills video1** (ya en overlay HTML):
- 3.64s → "IA"
- 26.51s → "Claude"  
- 41.77s → "Claude"
- 62.30s → "Claude Code"

**Duracion new_base_video1.mp4:** 86.367s  
**Palabras en transcript:** 284 (en `edit/transcripts/new_base_video1.json`, timestamps en ms)

---

## PASOS EXACTOS PARA COMPLETAR VIDEO 1

### Paso 1 — Fix overlay WebM (re-renderizar con alpha)
```bash
cd "C:/Users/duvan/OneDrive/Documentos/transcriptor/edit/hyperframes/overlay-comp"
# Eliminar el webm sin alpha
del overlay_v1.webm
# Re-renderizar
npx hyperframes render --format webm -o overlay_v1.webm .
# Verificar alpha
ffprobe -v quiet -show_entries stream=pix_fmt -of default=noprint_wrappers=1 overlay_v1.webm
# Debe mostrar: pix_fmt=yuva420p
```

### Paso 2 — Render subtitulos WebM
```bash
cd "C:/Users/duvan/OneDrive/Documentos/transcriptor/edit/hyperframes/subtitles-comp"
npx hyperframes render --format webm -o subtitles_v1.webm .
# Verificar: debe tener pix_fmt=yuva420p y duracion ~86s
```

### Paso 3 — Copiar WebMs a clips_hf
```bash
copy "edit\hyperframes\subtitles-comp\subtitles_v1.webm" "edit\clips_hf\subtitles_v1.webm"
copy "edit\hyperframes\overlay-comp\overlay_v1.webm" "edit\clips_hf\overlay_v1.webm"
```

### Paso 4 — Composite final video1
```bash
ffmpeg -y \
  -i "videos_editar/edit/new_base_video1.mp4" \
  -vcodec libvpx-vp9 -i "edit/clips_hf/subtitles_v1.webm" \
  -vcodec libvpx-vp9 -i "edit/clips_hf/overlay_v1.webm" \
  -filter_complex "[0:v][1:v]overlay=x=0:y=0:format=auto[v1];[v1][2:v]overlay=x=0:y=0:format=auto[vout]" \
  -map "[vout]" -map "0:a" \
  -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p \
  -c:a copy -movflags +faststart \
  "videos_editar/edit/final_video1.mp4"
```

### Paso 5 — Extraer frames de verificacion video1
```bash
# Segundo 2 — hook visible
ffmpeg -y -ss 2 -i "videos_editar/edit/final_video1.mp4" -vframes 1 -q:v 2 "edit/check_v1_hook.jpg"
# Segundo 7 — sin hook (desaparecio a los 5s)
ffmpeg -y -ss 7 -i "videos_editar/edit/final_video1.mp4" -vframes 1 -q:v 2 "edit/check_v1_mid.jpg"
# Segundo 30 — subtitulos mid-video
ffmpeg -y -ss 30 -i "videos_editar/edit/final_video1.mp4" -vframes 1 -q:v 2 "edit/check_v1_sub.jpg"
```

---

## PASOS EXACTOS PARA VIDEO 2 (pipeline completo desde cero)

### Fase 1 — Silence cut 500ms
```python
# Usar: C:/Users/duvan/skills/video-use/helpers/silence_cut.py
# Input: videos_editar/edit/video2.MP4 (140.13s)
# Output: videos_editar/edit/base_video2.mp4
# EDL: videos_editar/edit/edl_video2.json
# Threshold: 500ms (0.5s)
```

### Fase 2 — Transcripcion
```python
# transcribe.py esta en: C:/Users/duvan/OneDrive/Documentos/transcriptor/transcribir.py
# Input: videos_editar/edit/base_video2.mp4
# Output: edit/transcripts/base_video2.json
# CRITICO: El archivo guarda timestamps en SEGUNDOS → convertir a ms multiplicando x1000
# despues de transcribir:
# for w in transcript["words"]: w["start"] = int(round(w["start"] * 1000)); w["end"] = int(round(w["end"] * 1000))
```

### Fase 2b — detect_repetitions + nuevo base
```python
# Script: C:/Users/duvan/skills/video-use/helpers/detect_repetitions.py
# Input transcript: edit/transcripts/base_video2.json (timestamps en ms)
# Output cuts: lista de {start_s, end_s, reason}
# Aplicar cortes con ffmpeg filter_complex
# Guardar keeps: videos_editar/edit/all_keeps_video2.json
# Output video: videos_editar/edit/new_base_video2.mp4
# Remap transcript: edit/transcripts/new_base_video2.json
```

### Fases 3, 4, 5 — Igual que video1 pero con paths _v2

---

## TEMPLATE SUBTITULOS HTML (para video2)

```python
# Codigo Python para generar subtitulos HTML desde transcript:

import json
from pathlib import Path

transcript = json.loads(Path("edit/transcripts/new_base_video2.json").read_text(encoding="utf-8"))
words = transcript["words"]
VIDEO_DURATION = # duracion real de new_base_video2.mp4

def build_cues(words, words_per_cue=2):
    cues = []
    for i in range(0, len(words), words_per_cue):
        group = words[i:i+words_per_cue]
        if not group: continue
        start_s = group[0]["start"] / 1000.0
        next_start = words[i + words_per_cue]["start"] / 1000.0if i + words_per_cue < len(words) else start_s + 2.0
        cues.append({"start_s": start_s, "duration_s": next_start - start_s, "words": [w["text"] for w in group]})
    return cues
```

---

## TEMPLATE OVERLAY HTML (para video2)

```html
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=1080, height=1920" />
<script src="https://cdn.jsdelivr.net/npm/gsap@3.14.2/dist/gsap.min.js"></script>
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
html, body { width: 1080px; height: 1920px; overflow: hidden; background: transparent; }
.hook-box {
  position: absolute; top: 110px; left: 50%; transform: translateX(-50%);
  background: rgba(255,255,255,0.95); color: #111111;
  font-family: Inter, system-ui, sans-serif;
  font-size: 32px; font-weight: 700; line-height: 1.3; letter-spacing: -0.01em; text-align: center;
  padding: 12px 18px; border-radius: 12px; max-width: 82%;
  box-shadow: 0 2px 12px rgba(0,0,0,0.20); opacity: 0;
}
.keyword-pill {
  position: absolute; top: 42%; left: 50%; transform: translateX(-50%) translateY(-50%);
  background: #111111; color: #ffffff;
  font-family: Inter, system-ui, sans-serif;
  font-size: 38px; font-weight: 800; padding: 10px 20px;
  border-radius: 10px; white-space: nowrap; opacity: 0;
}
</style>
</head>
<body>
<div id="root" data-composition-id="overlay-comp" data-start="0" data-duration="DURACION" data-width="1080" data-height="1920">
<div class="hook-box" id="hook">HOOK_TEXT_AQUI</div>
<!-- pills aqui -->
</div>
<script>
window.__timelines = window.__timelines || {};
const tl = gsap.timeline({ paused: true });
gsap.set('#hook', { opacity: 0, y: -30 });
tl.to('#hook', { opacity: 1, y: 0, duration: 0.4, ease: 'power3.out' }, 0.1);
tl.to('#hook', { opacity: 0, duration: 0.3, ease: 'power2.in' }, 5.0);
document.querySelectorAll('.keyword-pill').forEach(function(el) {
  const start = parseFloat(el.dataset.start || 0);
  const dur = parseFloat(el.dataset.duration || 2);
  gsap.set(el, { opacity: 0, y: 15, scale: 0.9 });
  tl.to(el, { opacity: 1, y: 0, scale: 1, duration: 0.3, ease: 'back.out(1.4)' }, start);
  tl.to(el, { opacity: 0, duration: 0.2, ease: 'power2.in' }, start + dur - 0.2);
});
tl.to({}, { duration: DURACION }, 0);
window.__timelines["overlay-comp"] = tl;
</script>
</body>
</html>
```

---

## KEYWORDS QUE ACTIVAN PILLS

```python
KEYWORD_PILLS = {
    "claude": "Claude", "claude code": "Claude Code",
    "chatgpt": "ChatGPT", "chat gpt": "ChatGPT", "gpt": "GPT",
    "meta ads": "Meta ADs", "facebook ads": "Facebook Ads", "fb ads": "FB Ads",
    "instagram": "Instagram", "tiktok": "TikTok",
    "agente": "Agente IA", "agente ia": "Agente IA",
    "automatizacion": "Automatizacion", "ugc": "UGC",
    "ecommerce": "Ecommerce", "whatsapp": "WhatsApp",
    "notion": "Notion", "make": "Make.com", "n8n": "n8n",
    "openai": "OpenAI", "gemini": "Gemini", "anthropic": "Anthropic",
    # NOTA: transcripcion puede decir "Cloud" cuando el orador dice "Claude"
}
```

---

## FFMPEG COMPOSITING — REGLA CRITICA

```bash
# CORRECTO — -vcodec libvpx-vp9 ANTES del -i del webm
ffmpeg -y \
  -i base_video.mp4 \
  -vcodec libvpx-vp9 -i subtitles.webm \
  -vcodec libvpx-vp9 -i overlay.webm \
  -filter_complex "[0:v][1:v]overlay=x=0:y=0:format=auto[v1];[v1][2:v]overlay=x=0:y=0:format=auto[vout]" \
  -map "[vout]" -map "0:a" \
  -c:v libx264 -preset fast -crf 18 -pix_fmt yuv420p \
  -c:a copy -movflags +faststart \
  output.mp4

# VERIFICAR ALPHA antes de compositar:
ffprobe -v quiet -show_entries stream=pix_fmt -of default=noprint_wrappers=1 archivo.webm
# Debe decir: pix_fmt=yuva420p  (NO yuv420p)
```

---

## ESTRUCTURA DE ARCHIVOS

```
C:/Users/duvan/OneDrive/Documentos/transcriptor/
├── videos_editar/edit/
│   ├── video1.MP4                    <- fuente original v1
│   ├── video2.MP4                    <- fuente original v2 (140.13s)
│   ├── base_video1.mp4               <- v1 despues silence cut (97.37s)
│   ├── new_base_video1.mp4           <- v1 limpio content+silence cuts (86.367s) ✅
│   ├── edl_video1.json               <- segmentos del silence cut v1
│   ├── all_keeps_video1.json         <- rangos keep para remap transcript v1
│   └── final_video1.mp4              <- OUTPUT FINAL v1 (pendiente)
├── edit/
│   ├── transcripts/
│   │   ├── base_video1.json          <- transcript v1 pre-content-cuts (ms)
│   │   └── new_base_video1.json      <- transcript v1 remapeado (284 palabras, ms) ✅
│   ├── hyperframes/
│   │   ├── subtitles-comp/
│   │   │   └── index.html            <- 142 cues, 28px, bottom 385px ✅
│   │   └── overlay-comp/
│   │       ├── index.html            <- hook + 4 pills, 86.367s ✅
│   │       └── overlay_v1.webm       <- ⚠️ SIN ALPHA (yuv420p) — re-renderizar
│   └── clips_hf/
│       ├── subtitles_v1.webm         <- ❌ pendiente
│       └── overlay_v1.webm           <- ❌ pendiente (copiar despues de fix)
├── claudemd/
│   └── CLAUDE.md                     <- reglas sistema visual
└── edit/
    └── hyperframes/
        └── CLAUDE.md                 <- reglas HyperFrames
```

---

## HELPERS DISPONIBLES

```
C:/Users/duvan/skills/video-use/helpers/
├── silence_cut.py          <- Fase 1: cortar silencios >= threshold
├── detect_repetitions.py   <- Fase 2: detectar n-grams repetidos
└── gen_subtitles_hf.py     <- Fase 3: generar HTML subtitulos (usar directamente o adaptar)
```

---

## TAREA FINAL REQUERIDA

Cuando ambos videos esten completos, mostrar los 6 frames al usuario:
- `edit/check_v1_hook.jpg`  (video1, segundo 2, hook visible)
- `edit/check_v1_mid.jpg`   (video1, segundo 7, sin hook)
- `edit/check_v1_sub.jpg`   (video1, segundo 30, subtitulos)
- `edit/check_v2_hook.jpg`  (video2, segundo 2, hook visible)
- `edit/check_v2_mid.jpg`   (video2, segundo 7, sin hook)
- `edit/check_v2_sub.jpg`   (video2, segundo 30, subtitulos)

**El usuario NO quiere interrupciones durante el proceso. Ejecutar todo de forma autonoma.**

---

## ACCIONES INMEDIATAS PRIORIZADAS

| Prioridad | Accion | Notas |
|-----------|--------|-------|
| 1 | Re-render `overlay_v1.webm` con alpha correcto | Verificar `pix_fmt=yuva420p` |
| 2 | Render `subtitles_v1.webm` (puede necesitar `--quality draft`) | Verificar `pix_fmt=yuva420p` |
| 3 | Composite `final_video1.mp4` | Solo cuando ambos webm tengan alpha |
| 4 | Extraer frames check_v1_*.jpg | 3 frames en segundos 2, 7, 30 |
| 5 | Pipeline completo video2 | Fases 1→5 desde cero |
| 6 | Mostrar 6 frames al usuario | Solo al final de todo |

---

*Handoff creado: 2026-05-03*  
*Session anterior fallo en render de HyperFrames despues de multiple intentos*
